### **Admin Actions**

- **Register and Login** - Jayanth
- **View All Users** - Jayanth
- **View All Retailers** - Jayanth
- **View Complaints** - Jayanth
- **Managing Users and Retailers** - Ganesh, Mahendra, Jayanth
- **View All Registration Requests Submitted by Retailers** - Ganesh, Mahendra, Jayanth

---

### **Buyer Actions**

- **Get Email Notification** - Deepthi, Chetana, Bhanu
- **View Product Details** - Deepthi
- **Browse Product by Category** - Chetana
- **Add Products to Cart** - Chetana
- **Remove Products from Cart** - Deepthi
- **Bill Checkout** - Bhanu
- **Rate and Review** - Bhanu
- **View Order History** - Chetana
- **Complaint Against Seller** - Bhanu
- **Save Product as Favorite** - Deepthi
- **Generate Invoice** - Deepthi

---

### **Retailer Actions**

- **Manage Inventory (Remove Products)** - Mahendra
- **Add Products** - Ganesh
- **Review Orders** - Mahendra
- **Manage Discounts** - Ganesh
- **Get Notifications** - Mahendra
- **Low Stock Inventory** - Ganesh, Mahendra
