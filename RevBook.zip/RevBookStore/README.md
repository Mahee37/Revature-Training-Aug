Check Project_Allocation file, To know your task.

Check The Dependencies

Check the Reference Project P0 to Complete tasks
