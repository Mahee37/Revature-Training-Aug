package com.RevBookStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RevBookStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(RevBookStoreApplication.class, args);
	}

}
