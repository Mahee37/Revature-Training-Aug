package com.RevBookStore.controller;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.RevBookStore.entity.Products;

import com.RevBookStore.service.SellerServiceInterface;


@Controller

@RequestMapping("product")
public class ProductController {
	
	@Autowired
	private SellerServiceInterface sellerServiceInterface;
	
	@PostMapping
	public ModelAndView addProduct(@RequestParam("name") String name,
			                       @RequestParam("description") String description,
			                       @RequestParam("category") String category,
			                       @RequestParam("price") String price,
			                       @RequestParam("discount_price") String discount_price,
			                       @RequestParam("imageUrl") String imageUrl) {
		System.out.println(name);
		System.out.println(description);
		System.out.println(category);
		System.out.println(price);
		System.out.println(imageUrl);
		//Long userId = (Long) request.getSession(true).getAttribute("id");
		ModelAndView mv = new ModelAndView();
		Long userId =1l;
		//if user-id is null 
//		if(userId == null) {
//			mv.setViewName("login.jsp");
//			return mv;
//		}
		
		double parsedPrice;
		try {
			parsedPrice = Double.parseDouble(price);
		}catch(NumberFormatException e) {
			String err = "invalid price format";
			mv.addObject("error",err);
			mv.setViewName("add.jsp");
			return mv;
		}
		
		Products product = new Products();
		product.setName(name);
		product.setDescription(description);
		product.setCategory(category);
		product.setPrice(parsedPrice);
		
		if(discount_price!=null) {
			try {
				double discountPrice = Double.parseDouble(discount_price);
				product.setDiscount_price(discountPrice);
				}catch(NumberFormatException e) {
					String err = "invalid price format";
					mv.addObject("error",err);
					mv.setViewName("add.jsp");
					return mv;
				}
		}
		product.setImageUrl(imageUrl);
		
		boolean productAdded = sellerServiceInterface.addProduct(userId,product);
		if(productAdded) {
			List<Products> products = sellerServiceInterface.viewProducts();
			mv.addObject("product_list",products);
			mv.setViewName("/inventory.jsp");
			return mv;
			
		}else {
			String err = "Something went wrong";
			mv.addObject("error",err);
			mv.setViewName("add.jsp");
			return mv;
		}
		
}
	

	@RequestMapping("viewProducts")
	public ModelAndView viewProducts() {
		
		List<Products> products = sellerServiceInterface.viewProducts();
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("product_list",products);
		mv.setViewName("/inventory.jsp");
		return mv;
	}
	
    
	
}
