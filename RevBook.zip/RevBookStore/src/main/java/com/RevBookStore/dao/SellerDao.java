package com.RevBookStore.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

import com.RevBookStore.entity.Products;



@Repository
public class SellerDao implements SellerDaoInterface {

	@Autowired
	private SessionFactory sf;
	
	public boolean addProduct(Long userId, Products product) {
		
		System.out.println(userId);
		System.out.println(product.getName());
		Session ss = sf.openSession(); // for hiberate initialization
		Transaction et = ss.getTransaction();  //transaction initialization
		et.begin(); // begin the transaction
		
		ss.persist(product); // hibernate
		
		et.commit(); // commit the transaction
		return true;
	}

	@Override
	public List<Products> viewProducts() {
		Session ss = sf.openSession();
		Query q = ss.createQuery("from com.RevBookStore.entity.Products p");
		List<Products> list = q.getResultList();
		return list;
	}

}
