package com.RevBookStore.dao;

import java.util.List;

import com.RevBookStore.entity.Products;

public interface SellerDaoInterface {

	boolean addProduct(Long userId, Products product);

	List<Products> viewProducts();

}
