package com.RevBookStore.entity;

public class Seller {
    
}
