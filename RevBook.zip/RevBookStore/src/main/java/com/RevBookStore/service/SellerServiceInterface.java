package com.RevBookStore.service;

import java.util.List;

import com.RevBookStore.entity.Products;

public interface SellerServiceInterface {

	boolean addProduct(Long userId, Products product);

	List<Products> viewProducts();

}
